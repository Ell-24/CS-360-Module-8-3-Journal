package com.example.cs360pro3eh;

import android.app.Notification;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class Inventory extends AppCompatActivity {

    //Define
    Button NotificationButton;
    Button AddNewProductButton;
    RecyclerView recyclerView;
    ArrayList<String> product, quantity, location;
    InventoryDB DB;
    InvAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        //Connect buttons with layout ID's
        NotificationButton = (Button) findViewById(R.id.notificationButton);
        AddNewProductButton = (Button) findViewById(R.id.addNewProductButton);
        DB = new InventoryDB(Inventory.this);
        product = new ArrayList<>();
        quantity = new ArrayList<>();
        location = new ArrayList<>();
        recyclerView = findViewById(R.id.InvTable);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(Inventory.this));
        adapter = new InvAdapter(this, product, quantity, location);
        ShowInventory();
    }

     void ShowInventory() {
        Cursor cursor = DB.getData();
        if (cursor.getCount()==0) {
            Toast.makeText(Inventory.this, "No products yet", Toast.LENGTH_SHORT).show();
            return;
        }
        else {
            while(cursor.moveToNext()) {
                product.add(cursor.getString(0));
                quantity.add(cursor.getString(1));
                location.add(cursor.getString(2));
            }
        }







        //On click transition to notifications screen
        NotificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Inventory.this,Notification.class);
                startActivity(intent);
            }
        });

        //On click transition to add new product screen
        AddNewProductButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Inventory.this,AddProduct.class);
                startActivity(intent);
            }
        });
    }
}