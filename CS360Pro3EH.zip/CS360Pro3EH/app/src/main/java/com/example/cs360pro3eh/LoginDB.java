package com.example.cs360pro3eh;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.content.Context;
import androidx.annotation.Nullable;

//initialize SQLite DB
public class LoginDB extends SQLiteOpenHelper {

    public static final String DatabaseName = "UserDataBase";

    public LoginDB(@Nullable Context context) {
        super(context, "UserDataBase", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase userDB) {
        userDB.execSQL("create Table users(username TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase userDB, int oldVersion, int newVersion) {
        userDB.execSQL("drop Table if exists users");
    }

    //insert function method
    public Boolean insertUserData(String username, String password) {
        SQLiteDatabase userDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = userDB.insert("users", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    //Check if username exists within database
    public boolean CheckUserExists (String username) {
        SQLiteDatabase userDB = this.getWritableDatabase();
        Cursor cursor = userDB.rawQuery("Select*from users where username = ?", new String[]{username});
        if (cursor.getCount() > 0) {
            return true;
        }
        else {
            return false;
        }
    }

    //check credentials within database
    public boolean validate (String username, String password) {
        SQLiteDatabase userDB = this.getWritableDatabase();
        Cursor cursor = userDB.rawQuery("Select*from users where username = ? and password = ?", new String[]{username, password});
        if (cursor.getCount() > 0) {
            return true;
        }
        else {
            return false;
        }
    }

}
