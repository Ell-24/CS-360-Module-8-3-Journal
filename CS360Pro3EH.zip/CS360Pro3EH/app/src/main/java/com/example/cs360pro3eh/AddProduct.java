package com.example.cs360pro3eh;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class AddProduct extends AppCompatActivity {

    //Define Button and fields
    private Button CancelProductButton;
    private Button CreateProductButton;
    private EditText CreateProductName;
    private EditText CreateProductQTY;
    private EditText CreateProductLoc;
    InventoryDB DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_product);

        //Connect button with layout ID
        CancelProductButton=(Button) findViewById(R.id.cancelProductButton);
        CreateProductButton=(Button) findViewById(R.id.createProductButton);
        CreateProductName=(EditText) findViewById(R.id.createProductName);
        CreateProductQTY=(EditText) findViewById(R.id.createProductQty);
        CreateProductLoc=(EditText) findViewById(R.id.createProductLoc);
        DB = new InventoryDB(this);

        //insert new product into data base method
        CreateProductButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //define fields
                String product = CreateProductName.getText().toString();
                String quantity = CreateProductQTY.getText().toString();
                String location = CreateProductLoc.getText().toString();

                Boolean checkFields = DB.insertStock(product, quantity, location);
                //let user know if product was successfully added or not
                if(checkFields == true) {
                    Toast.makeText(AddProduct.this, "Product added", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(AddProduct.this, Inventory.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(AddProduct.this, "Error Product not added", Toast.LENGTH_SHORT).show();
                }
            }
        });




        //On click transition to Inventory screen
        CancelProductButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(AddProduct.this, Inventory.class);
                startActivity(intent);
            }
        });
    }
}