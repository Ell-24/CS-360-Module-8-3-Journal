package com.example.cs360pro3eh;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class InvAdapter extends RecyclerView.Adapter<InvAdapter.MyViewHolder> {
    private Context context;
    private ArrayList productID, quantityID, locationID;

    public InvAdapter(Context context, ArrayList productID, ArrayList quantityID, ArrayList locationID) {
        this.context = context;
        this.productID = productID;
        this.quantityID = quantityID;
        this.locationID = locationID;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.stockinput,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.productID.setText(String.valueOf(productID.get(position)));
        holder.quantityID.setText(String.valueOf(quantityID.get(position)));
        holder.locationID.setText(String.valueOf(locationID.get(position)));
    }

    @Override
    public int getItemCount() {
        return productID.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView productID, quantityID, locationID;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            productID = itemView.findViewById(R.id.productField);
            quantityID = itemView.findViewById(R.id.quantityField);
            locationID = itemView.findViewById(R.id.locationField);
        }
    }
}
