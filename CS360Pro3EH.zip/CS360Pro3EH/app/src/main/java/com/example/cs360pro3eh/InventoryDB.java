package com.example.cs360pro3eh;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.content.Context;
import androidx.annotation.Nullable;

//initialize SQLite DB
public class InventoryDB extends SQLiteOpenHelper {
    public InventoryDB(Context context) {
        super(context, "InventoryDataBase", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase inventoryDB) {
        inventoryDB.execSQL("create Table stock(product TEXT primary key, quantity TEXT, location TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase inventoryDB, int oldVersion, int newVersion) {
        inventoryDB.execSQL("drop Table if exists stock");
    }

    //insert function method
    public Boolean insertStock(String product, String quantity, String location) {
        SQLiteDatabase userDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("product", product);
        contentValues.put("quantity", quantity);
        contentValues.put("location", location);
        long result = userDB.insert("stock", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    //return data fields
    public Cursor getData() {
        SQLiteDatabase userDB = this.getWritableDatabase();
        Cursor cursor = userDB.rawQuery("select*from stock", null);
        return cursor;
    }


}