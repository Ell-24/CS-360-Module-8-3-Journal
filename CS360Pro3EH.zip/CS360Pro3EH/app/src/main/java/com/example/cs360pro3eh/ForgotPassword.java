package com.example.cs360pro3eh;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class ForgotPassword extends AppCompatActivity {

    private Button ForgotPassReturnButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_forgot_password);

        //Connect Button with Layout ID
        ForgotPassReturnButton=(Button)findViewById(R.id.forgotPassReturnButton);
        //Method to return to login screen once pressing return button
        ForgotPassReturnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ForgotPassword.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
}