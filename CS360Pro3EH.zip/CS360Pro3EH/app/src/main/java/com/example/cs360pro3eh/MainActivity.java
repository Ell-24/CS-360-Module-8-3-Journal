package com.example.cs360pro3eh;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    //Define Buttons
    private Button CreateAccountButton;
    private Button ForgotPasswordButton;
    private Button LoginButton;
    private EditText InputUsername;
    private EditText InputPassword;
    LoginDB DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        //Connect buttons with layout ID's
        CreateAccountButton=(Button)findViewById(R.id.createAccountButton);
        ForgotPasswordButton=(Button)findViewById(R.id.forgotPasswordButton);
        LoginButton=(Button)findViewById(R.id.loginButton);
        InputUsername = (EditText)findViewById(R.id.inputUsername);
        InputPassword = (EditText) findViewById(R.id.inputPassword);
        DB = new LoginDB(this);


        //On click transition to Inventory screen
        //Login Validation method implemented later
        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Define fields for database
                String username = InputUsername.getText().toString();
                String password = InputPassword.getText().toString();

                //Throw error if fields are blank
                if(InputUsername.equals("")||InputPassword.equals("")){
                    Toast.makeText(MainActivity.this,"Fields cannot be blank", Toast.LENGTH_SHORT).show();
                }

                else {
                    //If credentials are correct transition to Inventory screen
                    Boolean checkuser = DB.validate(username, password);
                    if (checkuser == true) {
                        Toast.makeText(MainActivity.this,"Success", Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(MainActivity.this,Inventory.class);
                        startActivity(intent);
                        finish();//User cannot return to login screen once logged in
                    }
                    //If credentials are wrong throw error
                    else {
                        Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        //On click transition to create account screen
        CreateAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,CreateAccount.class);
                startActivity(intent);
            }
        });

        //On click transition to forgot password screen
        ForgotPasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,ForgotPassword.class);
                startActivity(intent);
            }
        });


    }
}