package com.example.cs360pro3eh;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class CreateAccount extends AppCompatActivity {

    //Define Button and fields
    private Button CreateAccountReturnButton;
    private Button CreateAccountButton;
    private EditText CreateUsername;
    private EditText CreatePassword;
    LoginDB DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_account);

        //Connect Button and fields with layout ID
        CreateAccountReturnButton=(Button) findViewById(R.id.createAccountReturnButton);
        CreateAccountButton = (Button) findViewById(R.id.createAccountButton);
        CreateUsername = (EditText) findViewById(R.id.createUsername);
        CreatePassword = (EditText) findViewById(R.id.createPassword);
        DB = new LoginDB (this);

        //Add user credentials into the database
        CreateAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //define fields for function
                String username = CreateUsername.getText().toString();
                String password = CreatePassword.getText().toString();

                //throw error when fields are blank
                if (username.equals("")||password.equals("")) {
                    Toast.makeText(CreateAccount.this, "Fields cannot be blank", Toast.LENGTH_SHORT).show();
                }
                else {
                    //throw error if username exists in database
                    Boolean exists = DB.CheckUserExists(username);
                    if(exists == true) {
                        Toast.makeText(CreateAccount.this, "Username is already being used", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        //add credentials into database
                        Boolean insert = DB.insertUserData(username, password);
                        if(insert == true){
                            Toast.makeText(CreateAccount.this, "Creation Successful", Toast.LENGTH_SHORT).show();
                            Intent intent=new Intent(CreateAccount.this,MainActivity.class);
                            startActivity(intent);
                        }
                        //throw error if failed
                        else {
                            Toast.makeText(CreateAccount.this, "Creation Unsuccessful", Toast.LENGTH_SHORT).show();
                    }
                    }
                }

            }
        });

        //Method to return to login screen once pressing return button
        CreateAccountReturnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(CreateAccount.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
}